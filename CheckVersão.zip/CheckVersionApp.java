
---------[CARREGAR ARQUIVO PHP DA VERSÃO = 00 ]------
new CheckVersionApp(this).execute("https://tekashi.team/cmods/aide/datainfo.php");
-----------------------------------------------------


class CheckVersionApp extends AsyncTask <String, String, String> {
		
		private Context context;
		private ProgressDialog progress;
		
		public CheckVersionApp (Context ctx){
			this.context = ctx;
			this.progress = new ProgressDialog(ctx);
			this.progress.setCancelable(false);
			this.progress.setMessage("Checking app version...");
		}
		
		@Override
		protected void onPreExecute() {
			if (!progress.isShowing()){
				progress.show();
			}
		}
		
		@Override
		protected String doInBackground(String... string) {
			BufferedReader buffR = null;
			try {
				String url_address = string[0];
				URL url = new URL(url_address);
				URLConnection urlConnection = url.openConnection();
			    buffR = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
				StringBuffer strBuffer = new StringBuffer();
				String line;
				while ((line = buffR.readLine()) != null){
					strBuffer.append(line);
				}
				return strBuffer.toString();
			} catch (IOException e){
				e.printStackTrace();
			} finally {
				if (buffR != null){
					try {
						buffR.close();
					} catch (IOException e) {}
				}
			}
			return null;
		}
		

		@Override
		protected void onPostExecute(String result) {
			if (progress.isShowing()) progress.dismiss();
			if (result != null) {
				try {
					JSONObject object = new JSONObject(result);
					int versionFromJson = object.getInt("app_version");
					try {
						PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
						int version = pInfo.versionCode;
						if  (version < versionFromJson){
							new AlertDialog.Builder(context)
								.setMessage("The latest version is available, please update\n\n" + "Current version: v. " + version + "\nNew version: v."+ versionFromJson)
								.setPositiveButton("OK", new DialogInterface.OnClickListener(){
									@Override
									public void onClick(DialogInterface p1, int p2) {
										System.exit(1);
									}
								})
								.setCancelable(false)
								.show();
						} 
					} catch (PackageManager.NameNotFoundException e) {}

				} catch (final JSONException e) {
					e.printStackTrace();
				}
			} else {
				Toast.makeText(context, "Failed to checking app version", 1).show();
			}
		}
		
	}
