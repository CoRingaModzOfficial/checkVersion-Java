
<?php
$ackdata = array(
        "app_version" => 2
);
echo json_encode($ackdata);
?>